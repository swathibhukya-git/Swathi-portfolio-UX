
# Swathi Bhukya — Portfolio (Lavender Theme)

This folder contains a simple, static portfolio website built with HTML + CSS.

## Files
- `index.html` — main website
- `assets/*` — placeholder images (you can replace with your own screenshots)
- `resume.pdf` — (optional) add your ATS-friendly resume with this exact name, or update the link in `index.html`

---

## Easiest ways to share with recruiters

### Option A — GitHub Pages (free)
1. Create a new GitHub repo named `swathi-portfolio` (public).
2. Upload all files in this folder (`index.html`, `assets/*`, and optionally `resume.pdf`).
3. In GitHub: **Settings → Pages → Build and deployment** → Source: **Deploy from a branch**.
4. Select the `main` branch, root `/`, save.
5. Your site will be live at: `https://<your-username>.github.io/swathi-portfolio/`.
6. Share that link on your resume and applications.

### Option B — Netlify Drop (fast, no account needed to start)
1. Go to https://app.netlify.com/drop
2. Drag and drop the entire folder.
3. Netlify gives you a live URL instantly (you can rename it if you sign in).
4. Share the URL with recruiters.

### Option C — Vercel
1. Go to https://vercel.com/new and import your GitHub repo.
2. Vercel auto-detects static sites and deploys instantly.
3. Share the generated URL.

### Option D — Attach to Notion (embed your site)
1. Deploy with any option above (GitHub Pages/Netlify/Vercel).
2. In Notion, paste the live URL and choose **Create Embed**.
3. Now your Notion portfolio can include your website as an embedded block.

---

## Update the Resume Link
- If your resume file is named differently, open `index.html` and change:
  ```html
  <a href="resume.pdf" target="_blank" rel="noopener">Download Resume</a>
  ```
  to your actual file name, for example:
  ```html
  <a href="Swathi_Bhukya_Resume.pdf" target="_blank" rel="noopener">Download Resume</a>
  ```

## Replace Images
- Put your real screenshots in `/assets` with the same names **OR**
- Update the `<img src="...">` paths in the **Projects** section.

## Make It More Mobile-Responsive (optional quick tweak)
- Add this snippet inside `<style>` to adjust spacing for small screens:
  ```css
  @media (max-width: 640px) {
    section { margin: 2rem 0.75rem; padding: 0.75rem; }
    header { padding: 0.75rem 1rem; }
    nav a { margin: 0 0.5rem; }
  }
  ```
